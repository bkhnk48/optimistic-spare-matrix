
Authors: Upasana Nayak, Suraj Ketan Samal

The format of the statistics file are as follows:

Topology,k,txPackets,rxPackets,delaySum,jitterSum,lastDelay,lostPackets,timesForwarded,averageDelay,throughput
